
<!DOCTYPE html>
<html lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="theme-color" content="#F06966">
    <meta name="description" />
    <title>openvpn-install</title>
    <link href="/styles/dlp?v=04mwxuXe6tLv3cJj4Czr1pP35U3kFbBj05XhO-6Uejc1" rel="stylesheet"/>

</head>

<body>
    <div id="adx-1565" data-wid="22ab12ca-341b-48dd-8f72-8b1af6ed27e6" style="position:sticky; z-index:99999; top:0px;width:100%;"></div>
    <div id="adx-1566" data-wid="9b475e1d-f0ca-4f2b-9cb9-28976ef46976" style="position:fixed; z-index:99999; bottom:0px;width:100%;"></div>

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col col-lg-8">
                <nav class="navbar navbar-expand-lg navbar-light flex-row-reverse">
                    <a class="navbar-brand" href="https://www.picofile.com">
                        <img src="https://www.picofile.com/content/images/logo-2.png" alt="PicoFile.com - فضای رایگان آپلود فایل و آپلود عکس">
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                        <div class="navbar-nav">
                            <a class="nav-item nav-link" href="https://utop.ir">تبلیغات</a>
                            <a class="nav-item nav-link" href="https://www.picofile.com/privacy">حریم شخصی کاربران</a>
                            <a class="nav-item nav-link" href="https://www.picofile.com/terms">قوانین و مقررات</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
            <div class="row">
                <div class="col px-0">
                    <div class="info-box">
                        <div class="row justify-content-center align-items-center">
                            <div class="col-2 col-sm-4 col-lg-2 share-button-wrapper">
                                <button class="btn btn-circle btn-light share-btn" id="shareButton">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                         fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                         stroke-linejoin="round" class="feather feather-share-2">
                                        <circle cx="18" cy="5" r="3"></circle>
                                        <circle cx="6" cy="12" r="3"></circle>
                                        <circle cx="18" cy="19" r="3"></circle>
                                        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
                                        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
                                    </svg>
                                </button>
                                <div class="share-container" id="shareContainer">
                                    <a href="https://telegram.me/share/url?url=https://s34.picofile.com/file/8490416350/openvpn_install.sh.html" class="share-btn-telegram" target="_blank"></a>
                                    <a href="https://wa.me/?text=https://s34.picofile.com/file/8490416350/openvpn_install.sh.html" class="share-btn-whatsapp" target="_blank"></a>
                                    <a href="https://twitter.com/share?text=openvpn-install&url=https://s34.picofile.com/file/8490416350/openvpn_install.sh.html" class="share-btn-twitter" target="_blank"></a>
                                    <a href="mailto:?subject=openvpn-install&body=https://s34.picofile.com/file/8490416350/openvpn_install.sh.html" class="share-btn-email" target="_blank"></a>
                                </div>
                            </div>
                            <div class="col-12 col-sm-8 col-lg-6 text-left">
                                <h1 class="file-title">openvpn-install.sh</h1>
                                <span class="file-size">42 KB</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<div class="row justify-content-center">


</div>
        <div class="row justify-content-center mt-2 mt-md-4 mb-0 mb-md-5" id="centerContainer">
            <div class="col col-lg-9 col-xl-8">
                <div class="row flex-column position-relative">
                    <div class="col-12 col-md-6 order-1 order-md-1 text-center text-lg-right pr-lg-0 px-0 px-md-2 aa-container">
                        <div id="adx-1571" data-wid="b8a3ef26-d210-4c90-b1b5-65690c410b43"></div><div id="adx-1572" data-wid="472da03c-d6b1-4ebb-90bc-5c3c532127d9"></div>


                    </div>
                    <div class="col-12 col-md-6 order-3 order-md-2 text-center text-lg-right pr-lg-0 px-0 px-md-2 aa-container">


                    </div>
                    <div class="col-12 col-md-6 order-2 order-md-3 position-md-absolute px-0 my-4 my-md-0">
                        <div class="info-box rounded-box p-0 mr-auto ml-auto" id="infoBox">

                                <div class="text-center m-3 m-md-2 m-lg-3">
                                    <a href="https://utopclick.com/banner/click/?url=http%3a%2f%2fmci.com&amp;adid=1973" class="a-link mb-0" rel="nofollow noopener" target="_blank">
                                        <img src="https://utopclick.com/b/6F8971F7-9F70-485C-B96C-36D0C7E7FC6C-1973.gif" title="Hamraheavval" alt="Hamraheavval" />
                                    </a>
                                </div>

                            <div class="download-form mr-auto ml-auto text-center">
                                    <button id="getDownloadLink" class="btn btn-primary btn-icon icon-link btn-lg">
                                        <span class="btn-text">دریافت لینک دانلود</span>
                                        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                    </button>
                                    <div id="downloadLinkBox" class="form-group download-link-group m-3 m-md-2 m-lg-3 m-xl-2 hidden">
                                        <label for="downloadLinkInput">لینک دانلود</label>
                                        <input type="url" class="form-control mb-3" id="downloadLinkInput" spellcheck="false" readonly>
                                        <a href="" id="downloadLink" class="btn btn-primary btn-lg btn-icon icon-download">دانلود فایل</a>
                                    </div>
                            </div>



                            <div id="adx-1569" data-wid="18835b86-d859-4c80-87f7-a132fee7e1f6"></div><div id="adx-1570" data-wid="11b36cef-b369-4c23-9cf1-1b209ea3fa51"></div>

                                <div class="terms-container">
                                    <p class="mr-auto ml-auto p-3">
                                        <img src="https://www.picofile.com/content/images/new/alert-triangle.svg" alt="هشدار" class="alert-sign">
                                        مسئولیت فایل آپلود شده بر عهده‌ی کاربر آپلودکننده می‌باشد، لطفا در صورتی که این
                                        فایل را ناقض قوانین می‌دانید
                                        <a href="https://www.picofile.com/abuse?file=https://s34.picofile.com/file/8490416350/openvpn_install.sh.html" target="_blank" class="btn btn-link p-0">به ما گزارش دهید</a>.
                                    </p>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="row justify-content-center mt-4 mb-3">
            <div class="col col-lg-9 px-0">
                <footer class="my-0 my-md-4 pt-3 px-3 px-lg-0">
                    &#169; کلیه حقوق محفوظ است 1404 پیکوفایل
                </footer>
            </div>
        </div>
    </div>



    <script src="https://adexofiles.ir/script/panel.adexo.ir_banner.js?sid=484"></script>

    <script src="/scripts/dlp?v=E2D79LY1ayXf3Nu7BmXMz1LVmPXM35myP4WprvE8t4g1"></script>


        <script>
            toastr.options = {
                "positionClass": "toast-top-center"
            }

            $(function () {
                $("#descriptionText").dotdotdot({
                    ellipsis: ' ... ',
                    wrap: 'word',
                    fallbackToLetter: true,
                    after: ".more-des",
                    watch: false,
                    height: 60,
                    tolerance: 0,
                    callback: function (isTruncated, orgContent) { },
                    lastCharacter: {
                        remove: [' ', ',', ';', '.', '!', '?'],
                        noEllipsis: []
                    }
                });

                var minHeight = $('#infoBox').css('height');
                $('#centerContainer').css('min-height', minHeight);
                resizeBox();
            })

            $(".more-des").click(function () {
                $("#descriptionText").trigger("destroy");
            });

            $('body').click(function () {
                $('#shareButton').removeClass('share-active');
            })

            $('#shareButton').click(function (e) {
                if ('share' in navigator) {
                    navigator.share({
                        title: 'page title',
                        text: 'description text',
                        url: 'page url'
                    });
                } else {
                    $(this).toggleClass('share-active');
                    e.stopPropagation();
                }
            })
            $('#shareContainer').click(function (e) {
                e.stopPropagation();
            })
            $('#downloadLinkInput').click(function () {
                $(this).select();
                document.execCommand('copy');
                toastr.success('لینک دانلود کپی شد.')
            })

            var resizeBox = function () {
                var minHeight = $('#infoBox').css('height');
                $('#centerContainer').css('min-height', minHeight);
            }
            $(window).resize(function () {
                resizeBox();
            })

            $("#getDownloadLink").click(function () {
                $(this).prop("disabled", true).addClass("btn-loading");
                $.ajax({
                    url: "/file/generateDownloadLink?fileId=8490416350",
                    type: "POST",
                    data: { "password": $("#filePassword").val() },
                    success: function (data) {
                        $("#passwordBox").hide();
                        $("#getDownloadLink").hide();
                        $("#downloadLink").attr("href", data);
                        $("#downloadLinkInput").val(data);
                        $("#downloadLinkBox").show();
                        $(".password-form").removeClass("password-form");
                    },
                    error: function (jqXHR) {
                        $("#getDownloadLink").prop("disabled", false).removeClass("btn-loading");

                        if (jqXHR.status == 500)
                            toastr.error("خطا در انجام عملیات");
                        else if (jqXHR.status == 403)
                            toastr.error("کلمه عبور نامعتبر است");
                        else if (jqXHR.status == 404)
                            toastr.error("در حال حاضر امکان دانلود این فایل وجود ندارد");
                    },
                    complete: function () {
                        resizeBox();
                    }
                });
            });

setInterval(function(){
resizeBox();
}, 3000);
        </script>
</body>

</html>